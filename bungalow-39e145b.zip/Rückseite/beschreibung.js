// Schlichte Beschreibung der Rückseite (auf Deutsch)
const beschreibung = `
Die Rückseite des Bungalows
trennt harmonisch das eigene Grundstück
mit dem hinteren Nachbargrundstück
Sie bekommen das Gefühl, nichts zu vermissen, 
sondern eher den Eindruck, 
einer kleinen, gemütlichen, ruhigen und separaten Welt vn 500qm
und dennoch mit insgesamt drei Nachbarn

export default beschreibung`;

export default beschreibung;