Vogelperspektive:

    - zwei Dachfenster im Schlafzimmer
    - 6 Solrpannel für die Stromerzeugung
    - 2 Essen für Ofenkamine Schlafzimmer und Wohnzimmer
    - 4 Wintergarten Dachfenster im Wohn/-Arbeitszimmer

Innenansicht:

    - mit der Betätigung des Türbuttons öffnen sich 2 Flügeltüren (Schlafzimmer, Küche), 2 Schiebetüren (Bad, Wohnzimmer), 1 Wintergartentür, 1 Haustür 

    - beim hover des TV's im Wohnzimmer bewegt dieser sich um 45°
    - bein anklicken der Beleuchtung (Toilette, Badewanne, begehbarer Kleiderschrank) leuchten diese
    - im Schlafzimmer funktioniert die Lampe in Regenbogenfarben auomatisch

    - Wohnzimmer befindet sich ein Aquarium 2 * 2 * 1 m mit drei selbstständig bewegende Fische, die beim hovern vor der Maus fliehen

Vorderansicht:

    - Badfenster, Flurfenster, Haustür, Wintergarten/-Wohnzimmerfenster
    //- Fenster und Tür werden beim hovern geöffnet


Linke Seite:

    - Altbau mit Holzverkleidung/-dämmung
    - Neubau Bad mit Putz/-dämmung und Glasbausteinwand
    - Wintergarten-Tür ist Aufgrund des L-Formes sichtbar und öffnet sich beim hovern (Inneneinrichtung wird in 3D gezeigt)

Rechte Seite:
    
    - Altbau eine Holz/-Dämmwand
    // - Neubau eine Putz/-Dämmwand 

Rückansicht:
    
    - eine komplette Holz/-Dämmwand mit drei Oberlichtern (Wohnzimmer, Küche, Schlafzimmer)

Swimmingpool: